import { icon } from "#functions";
import { brBuilder, ComponentData, createLinkButton, createMediaGallery, Separator, wrapButtons } from "@magicyan/discord";
import { codeBlock } from "discord.js";

export type StepData = ComponentData[] | ComponentData;
export function stepsData(): StepData[] {
    return [
        [
            createMediaGallery(
                "https://constatic-docs.vercel.app/pt/docs-og/discord/start/image.png"
            ),
            `${icon.folder} Crie uma nova pasta para o seu projeto e abra ela no seu terminal`,
        ],
        brBuilder(
            `${icon.code} Use o comando abaixo para iniciar a CLI`,
            codeBlock("npx constatic@latest"),
            "-# Se estiver usando Bun, altere \"npx\" por \"bunx\"",
        ),
        brBuilder(
            `${icon.bot} Selecione a primeira opção: `,
            "- **Iniciar projeto de bot de discord**"
        ),
        brBuilder(
            `${icon.clipboard} Serão feitas algumas perguntas para preparar o seu projeto:`,
            codeBlock("md", brBuilder(
                "- Nome do projeto (caminho para a pasta)",
                "- Banco de dados (opcional)",
                "- Recursos extras (opcional)",
                "- Instalar dependências (opcional)",
            ))
        ),
        [
            brBuilder(
                "Depois que responder tudo, seu projeto será gerado",
                "e você já pode começar a desenvolver.",
            ),
            Separator.Default,
            brBuilder(
                "### Desenvolvendo seu bot",
                "Veja abaixo alguns conceitos dessa base de bots que",
                " você pode utilizar para construir bots modernos"
            ),
            ...wrapButtons(2,
                createLinkButton({
                    label: "Comandos",
                    emoji: icon.chatinputcommand,
                    url: "https://constatic-docs.vercel.app/docs/discord/commands"
                }),
                createLinkButton({
                    label: "Eventos",
                    emoji: icon.bell,
                    url: "https://constatic-docs.vercel.app/docs/discord/events"
                }),
                createLinkButton({
                    label: "Responders",
                    emoji: icon.buttonclick,
                    url: "https://constatic-docs.vercel.app/docs/discord/responders"
                }),
                createLinkButton({
                    label: "Bancos de dados",
                    emoji: icon.database,
                    url: "https://constatic-docs.vercel.app/docs/discord/databases"
                }),
            )
        ]
    ]
}