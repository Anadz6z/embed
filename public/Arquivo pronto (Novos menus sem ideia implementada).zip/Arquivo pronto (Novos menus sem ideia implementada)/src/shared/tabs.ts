import { icon } from "#functions";
import { brBuilder } from "@magicyan/discord";
import { RouteBases } from "discord.js";

export type TabKey = "backend" | "bots" | "database" | "api";

export interface TabData {
    label: string;
    title: string;
    description: string;
    emoji: string | { id: string };
    link?: {
        label: string;
        url: string;
    }
}

export function tabsData(): Record<TabKey, TabData> {
    return {
        backend: {
            label: "Backend",
            title: "Backend Essencial",
            emoji: icon.chip,
            description: brBuilder(
                "Nesta seção, você vai aprender como construir a base de qualquer",
                "aplicação backend, entendendo como funcionam servidores HTTP, gerenciamento",
                "de rotas, middlewares e autenticação. Exploramos conceitos como arquitetura",
                "em camadas, boas práticas de organização de código e segurança,",
                "preparando você para criar APIs escaláveis e de fácil manutenção.",
            )
        },
        api: {
            label: "APIs",
            title: "Integração de APIs",
            emoji: icon.plugin,
            description: brBuilder(
                "Aprenda a desenvolver e integrar APIs REST e GraphQL, criando endpoints",
                "eficientes e seguros para comunicação entre sistemas. Nesta aba, falamos",
                "sobre padrões de autenticação como JWT, versionamento de APIs, tratamento",
                "de erros e documentação com ferramentas como Swagger. Além disso, mostramos",
                "como consumir APIs externas de forma robusta, garantindo resiliência e",
                "escalabilidade."
            ),
            link: {
                label: "Mais informações",
                url: RouteBases.template
            }
        },
        database: {
            label: "Dados",
            title: "Banco de Dados",
            emoji: icon.database,
            description: brBuilder(
                "Domine o uso de bancos de dados no contexto backend, compreendendo a",
                "diferença entre bancos relacionais (como PostgreSQL) e NoSQL (como MongoDB).",
                "Explicamos como modelar dados de forma eficiente, criar consultas otimizadas e ",
                "manter a integridade da informação. Também abordamos técnicas importantes como",
                "migrations, transações e uso de ORMs como Prisma e Mongoose.",
            )
        },
        bots: {
            label: "Bots",
            title: "Bots de Discord",
            emoji: icon.bot,
            description: brBuilder(
                "Descubra como criar bots inteligentes para Discord, automatizando tarefas,",
                "gerenciando comunidades e interagindo com APIs externas. Abordamos desde a",
                "configuração inicial com Discord.js até a criação de comandos avançados, ",
                "integração com bancos de dados para persistência de dados, e boas práticas",
                "para garantir segurança, estabilidade e escalabilidade no desenvolvimento de bots."
            ),
            link: {
                label: "Confira mais",
                url: RouteBases.template
            }
        },
    }
}