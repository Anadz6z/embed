import { createCommand } from "#base";
import { settings } from "#settings";
import { createContainer, Separator } from "@magicyan/discord";
import { ApplicationCommandOptionType, ApplicationCommandType } from "discord.js";

createCommand({
    name: "separator",
    description: "app command",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name: "type",
            description: "command option",
            type: ApplicationCommandOptionType.String,
            choices: Object.keys(Separator).map(value => ({
                name: value, value,
            }))
        }
    ],
    async run(interaction){
        const type = interaction.options.getString("type", true) as keyof typeof Separator;
        
        const container = createContainer(
            settings.colors.azoxo,
            `## Separator ${type}`,
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel est eget nibh cursus consequat. Maecenas non ultrices felis. Nullam scelerisque nec mauris quis facilisis. Aliquam pulvinar nisl nibh.",
            Separator[type],
            "sit amet lobortis ante luctus vel. Curabitur pellentesque elit a nisl aliquet aliquam. Nunc vel posuere mauris, in scelerisque dui. Nunc eu tempor nisl",
        );

        await interaction.reply({
            flags: ["Ephemeral", "IsComponentsV2"],
            components: [container]
        });
    }
});