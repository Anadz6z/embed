import { createCommand } from "#base";
import { menus } from "#menus";

createCommand({
    name: "tabs",
    description: "app command",
    async run(interaction){
        await interaction.reply(menus.tabs("backend"))
    }
});