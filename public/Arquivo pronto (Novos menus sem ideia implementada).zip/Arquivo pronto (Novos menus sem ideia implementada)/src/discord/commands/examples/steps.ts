import { createCommand } from "#base";
import { menus } from "#menus";
import { stepsData } from "#shared/steps.js";

createCommand({
    name: "steps",
    description: "app command",
    async run(interaction){
        const steps = stepsData();

        const current = 0;
        const data = steps[current];
        const total = steps.length;

        await interaction.reply(menus.steps({ current, data, total }));
    }
});