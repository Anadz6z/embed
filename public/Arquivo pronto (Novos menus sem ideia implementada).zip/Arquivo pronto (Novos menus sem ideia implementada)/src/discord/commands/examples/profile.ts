import { createCommand } from "#base";
import { icon } from "#functions";
import { menus } from "#menus";
import { settings } from "#settings";
import { createContainer } from "@magicyan/discord";
import { ApplicationCommandOptionType, ApplicationCommandType } from "discord.js";

createCommand({
    name: "profile",
    description: "app command",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name: "member",
            description: "mention a member",
            type: ApplicationCommandOptionType.User,
            required: false,
        }
    ],
    async run(interaction){
        const { options, member: executor } = interaction;

        const member = options.getMember("member") ?? executor;

        await interaction.reply({
            flags: ["IsComponentsV2", "Ephemeral"],
            components: [createContainer(settings.colors.warning,
                `${icon.spinning} Buscando informações do membro! Aguarde...`
            )]
        });

        await member.fetch(true);

        await interaction.editReply(menus.profile(member, executor));

    }
});