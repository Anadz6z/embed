import { createCommand } from "#base";
import { menus } from "#menus";
import { ApplicationCommandType } from "discord.js";

createCommand({
    name: "settings",
    description: "app command",
    type: ApplicationCommandType.ChatInput,
    async run(interaction){
        const { guild } = interaction;
        interaction.reply(menus.settings.main(guild));
    }
});