import { createResponder, ResponderType } from "#base";
import { menus } from "#menus";
import { stepsData } from "#shared/steps.js";
import { z } from "zod";

createResponder({
    customId: "steps/:current",
    parse: z.object({
        current: z.number({ coerce: true })
    }).parse,
    types: [ResponderType.Button], cache: "cached",
    async run(interaction, { current }) {
        const steps = stepsData();

        const data = steps[current];
        const total = steps.length;

        await interaction.update(menus.steps({ current, data, total }));
    },
});