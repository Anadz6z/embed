import { createResponder, ResponderType } from "#base";
import { icon } from "#functions";
import { menus } from "#menus";
import { settings } from "#settings";
import { createContainer } from "@magicyan/discord";

createResponder({
    customId: "profile/:memberId/:action",
    types: [ResponderType.Button], cache: "cached",
    async run(interaction, { memberId, action }) {
        const { guild, member: executor } = interaction;

        await interaction.deferUpdate();

        const member = await guild.members
            .fetch(memberId)
            .catch(() => null);


        if (!member) {
            await interaction.editReply({
                components: [createContainer(settings.colors.danger,
                    `${icon.danger} O membro não está mais no servidor!`
                )]
            });
            return;
        }
        await member.fetch(true);
        
        switch(action){
            case "refresh":{
                await interaction.editReply(menus.profile(member, executor));
                return;
            }
            case "timeout":{
                
                return;
            }
            case "kick":{

                return;
            }
            case "ban":{

                return;
            }
        }

    },
});