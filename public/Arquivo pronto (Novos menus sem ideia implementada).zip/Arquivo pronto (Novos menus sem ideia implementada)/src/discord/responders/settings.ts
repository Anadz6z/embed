import { createResponder, ResponderType } from "#base";
import { menus } from "#menus";

createResponder({
    customId: "settings/:menu",
    types: [ResponderType.Button], cache: "cached",
    async run(interaction, { menu }) {
        const { guild } = interaction;
        
        await interaction.deferUpdate();
        
        switch(menu){
            case "main":{
                interaction.editReply(menus.settings.main(guild))
                return;
            }
            case "channels":{
                interaction.editReply(menus.settings.channels(guild))
                return;
            }
            case "roles":{
                interaction.editReply(menus.settings.roles(guild))
                return;
            }
            case "webhooks":{
                interaction.editReply(menus.settings.webhooks(guild))
                return;
            }
        }
    },
});