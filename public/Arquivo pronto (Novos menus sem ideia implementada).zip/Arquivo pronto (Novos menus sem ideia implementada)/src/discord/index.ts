import { setupCreators } from "#base";

export const { createCommand, createEvent, createResponder } = setupCreators({
    commands: {
        guilds: ["1055933117522776064"]
    }
});