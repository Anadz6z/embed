import { icon } from "#functions";
import { settings } from "#settings";
import { userStatus } from "#shared/status.js";
import { brBuilder, createContainer, createMediaGallery, createRow, createThumbArea, random, Separator } from "@magicyan/discord";
import { ButtonBuilder, ButtonStyle, GuildMember, time, type InteractionReplyOptions } from "discord.js";

export function profileMenu<R>(member: GuildMember, executor: GuildMember): R {
    const { guild, roles, user, presence } = member;

    const joinedAt = member.joinedAt ?? new Date();
    const noRoles = roles.highest.id === guild.id;

    const highestRole = noRoles ? "\`Sem cargo\`" : roles.highest
   
    const bannerURL = member.displayBannerURL({ size: 512 });
    const banner = bannerURL ? createMediaGallery(bannerURL) : null;
    
    const thumbArea = createThumbArea({
        content: brBuilder(
            `## ${icon.user} Perfil de ${member.displayName}`,
            `${highestRole} ${member} **@${user.username}**`,
            presence 
                ? `${icon.flask} Status: ${userStatus(presence.status)}` 
                : null,
            `${icon.calendar} Entrou no servidor ${time(joinedAt, "R")}`,
            `${icon.calendar} Conta criada ${time(user.createdAt, "R")}`,
        ),
        thumbnail: member.displayAvatarURL({ size: 1024 })
    });

    const roleList = Array.from(roles.cache.values())
        .filter(r => r.id !== member.guild.id);

    const rolesContent = noRoles ? null : brBuilder(
        `### ${icon.role} Cargos`,
        roleList.map(role => role.toString()).join(", "),
        "-# Inclui todos os cargos deste membro",
    );

    const otherContent = brBuilder(
        `### ${icon.chart} Estatísticas`,
        "> Informações sobre algumas estatísticas comuns deste membro",
        `${icon.send} Mensagems enviadas: \`${random.int(4000, 5000)}\``,
        `${icon.coin} Moedas: \`${random.int(12, 1000)}\``,
        `${icon.achievement} Conquistas: \`${random.int(1, 60)}\``,
        `${icon.receipt} Compras: \`${random.int(1, 100)}\``,
    )

    const customId = (action: string) => `profile/${member.id}/${action}`;

    const row = createRow(
        new ButtonBuilder({
            customId: customId("refresh"),
            style: ButtonStyle.Success,
            emoji: icon.reload,
        }),
        new ButtonBuilder({
            customId: customId("timeout"),
            style: ButtonStyle.Danger,
            emoji: icon.timedout,
            label: "Castigo",
            disabled: executor.id === member.id 
            || !executor.permissions.has("ModerateMembers")
        }),
        new ButtonBuilder({
            customId: customId("kick"),
            style: ButtonStyle.Secondary,
            emoji: icon.invisible,
            label: "Expulsar",
            disabled: executor.id === member.id 
            || !executor.permissions.has("KickMembers")
        }),
        new ButtonBuilder({
            customId: customId("ban"),
            style: ButtonStyle.Danger,
            emoji: icon.hammer,
            label: "Banir",
            disabled: executor.id === member.id 
            || !executor.permissions.has("BanMembers")
        }),
    );

    const container = createContainer({
        accentColor: noRoles 
            ? settings.colors.default 
            : member.displayHexColor,
        components: [
            banner,
            thumbArea,
            Separator.Default,
            rolesContent,
            otherContent,
            Separator.Default,
            row,
            `-# Painel de controle do perfil de ${member.displayName}`
        ]
    });

    return ({
        flags: ["Ephemeral", "IsComponentsV2"],
        components: [container]
    } satisfies InteractionReplyOptions) as R;
}