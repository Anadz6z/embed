import { profileMenu } from "./profile.js";
import { stepsMenu } from "./steps.js";
import { settingsChannelsMenu } from "./submenus/channels.js";
import { settingsMenu } from "./submenus/main.js";
import { settingsRolesMenu } from "./submenus/roles.js";
import { settingsWebhooksMenu } from "./submenus/webhooks.js";
import { simpleTabsMenu } from "./tabs.js";

export const menus = {
    tabs: simpleTabsMenu,
    profile: profileMenu,
    steps: stepsMenu,
    settings: {
        main: settingsMenu,
        channels: settingsChannelsMenu,
        roles: settingsRolesMenu,
        webhooks: settingsWebhooksMenu,
    }
}