import { icon } from "#functions";
import { settings } from "#settings";
import { StepData } from "#shared/steps.js";
import { createContainer, createSection, Separator } from "@magicyan/discord";
import { ButtonBuilder, ButtonStyle, type InteractionReplyOptions } from "discord.js";

interface StepMenuProps {
    data: StepData;
    current: number,
    total: number
}

export function stepsMenu<R>(props: StepMenuProps): R {
    const { data, current, total } = props;
    const prev = current - 1;
    const next = current + 1;

    const container = createContainer(settings.colors.azoxo,
        createSection({
            content: `## \` ${current + 1} \``,
            button: new ButtonBuilder({
                customId: `steps/${prev}`,
                emoji: icon.arrowu,
                disabled: current <= 0,
                style: ButtonStyle.Secondary,
            })
        }),
        Separator.Default,
        data,
        Separator.LargeHidden,
        Separator.Default,
        createSection({
            content: `-# ${current+1}/${total}`,
            button: new ButtonBuilder({
                customId: `steps/${next}`,
                emoji: icon.arrowd,
                disabled: next >= total,
                style: ButtonStyle.Secondary,
            })
        }),
    );

    return ({
        flags: ["Ephemeral", "IsComponentsV2"],
        components: [container]
    } satisfies InteractionReplyOptions) as R;
}