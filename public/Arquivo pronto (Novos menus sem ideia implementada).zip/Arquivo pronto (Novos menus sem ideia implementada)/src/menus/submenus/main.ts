import { icon } from "#functions";
import { settings } from "#settings";
import { brBuilder, createContainer, createRow, createThumbArea } from "@magicyan/discord";
import { ButtonBuilder, ButtonStyle, Guild, type InteractionReplyOptions } from "discord.js";

export function settingsMenu<R>(guild: Guild): R {
    const container = createContainer(settings.colors.azoxo,
        createThumbArea({
            content: brBuilder(
                `## ${icon.settings} Configurações`,
                "Escolha abaixo o que deseja configurar: ",
                `${icon.textc} Canais`,
                `${icon.role} Cargos`,
                `${icon.webhook} Webhooks`,
            ),
            thumbnail: guild.iconURL(),
        }),
        createRow(
            new ButtonBuilder({
                customId: "settings/channels",
                emoji: icon.textc,
                style: ButtonStyle.Secondary,
            }),
            new ButtonBuilder({
                customId: "settings/roles",
                emoji: icon.role,
                style: ButtonStyle.Secondary,
            }),
            new ButtonBuilder({
                customId: "settings/webhooks",
                emoji: icon.webhook,
                style: ButtonStyle.Secondary,
            }),
        ),
        `-# Configurações de ${guild.name}`
    );

    return ({
        flags: ["Ephemeral", "IsComponentsV2"],
        components: [container]
    } satisfies InteractionReplyOptions) as R;
}