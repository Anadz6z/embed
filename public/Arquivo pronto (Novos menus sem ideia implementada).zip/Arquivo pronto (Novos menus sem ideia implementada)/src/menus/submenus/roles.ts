import { icon } from "#functions";
import { settings } from "#settings";
import { brBuilder, createContainer, createRow, createThumbArea, Separator } from "@magicyan/discord";
import { ButtonBuilder, ButtonStyle, Guild, RoleSelectMenuBuilder, type InteractionReplyOptions } from "discord.js";
import { settingsNav } from "./nav.js";

export function settingsRolesMenu<R>(guild: Guild): R {
    const container = createContainer(settings.colors.azoxo,
        settingsNav({
            backCustomId: "settings/main",
            currLabel: "Cargos",
            currIcon: icon.role,
        }),
        Separator.Default,
        createThumbArea({
            content: brBuilder(
                `## ${icon.role} Configurar cargos`,
                "Selecione o cargo que deseja configurar",
                "- 👑 Cargo mestre",
                "- 🔵 Cargo de gerente",
                "- 🔴 Cargo de administrador",
                "- 🟢 Cargo de moderador",
                "- 🟣 Cargo de ajudante",
                "- ⭐ Cargo de vip",
                "- ⚪ Cargo de membro",
            ),
            thumbnail: guild.iconURL(),
        }),
        new RoleSelectMenuBuilder({
            customId: "settings/roles/key",
            placeholder: "Selecione o cargo",
        }),
        createRow(
            new ButtonBuilder({
                customId: "settings/roles/foo",
                label: "Foo",
                emoji: icon.success,
                style: ButtonStyle.Success
            }),
            new ButtonBuilder({
                customId: "settings/roles/bar",
                label: "Bar",
                emoji: icon.warning,
                style: ButtonStyle.Secondary
            }),
            new ButtonBuilder({
                customId: "settings/roles/baz",
                label: "Baz",
                emoji: icon.danger,
                style: ButtonStyle.Danger
            }),
        )
    );

    return ({
        flags: ["Ephemeral", "IsComponentsV2"],
        components: [container]
    } satisfies InteractionReplyOptions) as R;
}