import { icon, IconInfo } from "#functions";
import { createRow } from "@magicyan/discord";
import { ButtonBuilder, ButtonStyle } from "discord.js";

interface SettingsNavProps {
    backCustomId: string;
    currLabel: string;
    currIcon?: IconInfo;
}

export function settingsNav(props: SettingsNavProps){
    return createRow(
        new ButtonBuilder({
            customId: props.backCustomId,
            style: ButtonStyle.Secondary,
            emoji: icon.arrowl,
        }),
        new ButtonBuilder({
            customId: `current/menu/${Date.now()}`,
            label: props.currLabel,
            emoji: props.currIcon, 
            style: ButtonStyle.Secondary,
            disabled: true,
        }),
    )    
}