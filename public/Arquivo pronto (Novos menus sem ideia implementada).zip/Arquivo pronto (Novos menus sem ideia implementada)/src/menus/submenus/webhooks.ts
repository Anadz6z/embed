import { icon } from "#functions";
import { settings } from "#settings";
import { brBuilder, createContainer, createThumbArea, Separator, wrapButtons } from "@magicyan/discord";
import { ButtonBuilder, ButtonStyle, Guild, type InteractionReplyOptions } from "discord.js";
import { settingsNav } from "./nav.js";

export function settingsWebhooksMenu<R>(guild: Guild): R {
    const options = [
        {
            key: "message",
            emoji: icon.message,
            label: "Webhook de mensagens",
        },
        {
            key: "announcement",
            emoji: icon.announcementc,
            label: "Webhook de anúncios",
        },
        {
            key: "logs",
            emoji: icon.logs,
            label: "Webhook de logs",
        },
        {
            key: "products",
            emoji: icon.basket,
            label: "Webhook de produtos",
        },
        {
            key: "devices",
            emoji: icon.mobile,
            label: "Webhook de dispositivos",
        },
        {
            key: "transactions",
            emoji: icon.bank,
            label: "Webhook de transações",
        },
        {
            key: "bugs",
            emoji: icon.bug,
            label: "Webhook de bugs",
        },
        {
            key: "users",
            emoji: icon.users,
            label: "Webhook de usuários",
        },
        {
            key: "certificate",
            emoji: icon.certificate,
            label: "Webhook de certificados",
        },
    ]
    const container = createContainer(settings.colors.azoxo,
        settingsNav({
            backCustomId: "settings/main",
            currLabel: "Webhooks",
            currIcon: icon.webhook,
        }),
        Separator.Default,
        createThumbArea({
            content: brBuilder(
                `## ${icon.webhook} Configurar webhooks`,
                "Selecione o webhook que deseja configurar",
                options.map(option => `- ${option.emoji} ${option.label}`)
            ),
            thumbnail: guild.iconURL(),
        }),
        wrapButtons(5, options.map(option => new ButtonBuilder({
            customId: `settings/webhooks/${option.key}`,
            emoji: option.emoji,
            style: ButtonStyle.Secondary,
        })))
    );

    return ({
        flags: ["Ephemeral", "IsComponentsV2"],
        components: [container]
    } satisfies InteractionReplyOptions) as R;
}