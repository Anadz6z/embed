import { settings } from "#settings";
import { brBuilder, createContainer, createRow, createThumbArea, Separator } from "@magicyan/discord";
import { ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, Guild, type InteractionReplyOptions } from "discord.js";
import { settingsNav } from "./nav.js";
import { icon } from "#functions";

export function settingsChannelsMenu<R>(guild: Guild): R {
    const container = createContainer(settings.colors.azoxo,
        settingsNav({
            backCustomId: "settings/main",
            currLabel: "Canais",
            currIcon: icon.textc,
        }),
        Separator.Default,
        createThumbArea({
            content: brBuilder(
                `## ${icon.textc} Configurar canais`,
                "Selecione o canal que deseja configurar",
                "- 🌍 Canal global",
                "- 🔎 Canal de dúvidas",
                "- 🧰 Canal de gerenciamento",
                "- 📃 Canal de logs",
                "- 💡 Canal de sugestões",
            ),
            thumbnail: guild.iconURL(),
        }),
        new ChannelSelectMenuBuilder({
            customId: "settings/channels/key",
            placeholder: "Selecione o canal",
            channelTypes: [ChannelType.GuildText, ChannelType.GuildAnnouncement]
        }),
        createRow(
            new ButtonBuilder({
                customId: "settings/channels/foo",
                label: "Foo",
                emoji: icon.add,
                style: ButtonStyle.Success
            }),
            new ButtonBuilder({
                customId: "settings/channels/bar",
                label: "Bar",
                emoji: icon.boost2,
                style: ButtonStyle.Secondary
            }),
            new ButtonBuilder({
                customId: "settings/channels/baz",
                label: "Baz",
                emoji: icon.trashcan,
                style: ButtonStyle.Danger
            }),
        )
    );

    return ({
        flags: ["Ephemeral", "IsComponentsV2"],
        components: [container]
    } satisfies InteractionReplyOptions) as R;
}